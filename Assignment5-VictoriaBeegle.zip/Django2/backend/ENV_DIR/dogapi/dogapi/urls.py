"""
Book: Building RESTful Python Web Services
"""
from django.conf.urls import url
from dogs import views


urlpatterns = [
    url(r'^breeds/$', 
        views.BreedList.as_view(), 
        name=views.BreedList.name),
    url(r'^breeds/(?P<pk>[0-9]+)/$', 
        views.BreedDetail.as_view(),
        name=views.BreedDetail.name),
    url(r'^dogs/$', 
        views.DogList.as_view(),
        name=views.DogList.name),
    url(r'^dogs/(?P<pk>[0-9]+)/$', 
        views.DogDetail.as_view(),
        name=views.DogDetail.name),
    url(r'^$',
        views.ApiRoot.as_view(),
        name=views.ApiRoot.name),
]
