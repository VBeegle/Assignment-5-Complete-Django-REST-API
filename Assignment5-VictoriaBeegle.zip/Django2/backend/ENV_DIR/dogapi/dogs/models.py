"""
Book: Building RESTful Python Web Services
"""
from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator


class Breed(models.Model):
    name = models.CharField(max_length=50, blank=False, default='')
    TINY = 'XS'
    SMALL = 'S'
    MEDIUM = 'M'
    LARGE = 'L'
    
    SIZE_CHOICES = (
        (TINY, 'Tiny'),
        (SMALL, 'Small'),
        (MEDIUM, 'Medium'),
        (LARGE, 'Large'),
    )   
    size = models.CharField(
        max_length=4,
        choices=SIZE_CHOICES,
        default=MEDIUM,
    )
    frendliness = models.PositiveIntegerField(default=5, validators=[MinValueValidator(1), MaxValueValidator(5)])
    trainability = models.PositiveIntegerField(default=5, validators=[MinValueValidator(1), MaxValueValidator(5)])
    sheddingamount = models.PositiveIntegerField(default=5, validators=[MinValueValidator(1), MaxValueValidator(5)])
    exerciseneeds = models.PositiveIntegerField(default=5, validators=[MinValueValidator(1), MaxValueValidator(5)])
    
    class Meta:
        ordering = ('name',)

    def __str__(self):
        return self.name

class Dog(models.Model):
    name = models.CharField(max_length=200, blank=True, default='')
    age = models.IntegerField()
    color = models.CharField(max_length=200, blank=True, default='')
    favoritefood = models.CharField(max_length=200, blank=True, default='')
    favoritetoys = models.CharField(max_length=200, blank=True, default='')
    breed = models.ForeignKey(  # Foreign key Defintion for Breed
        Breed, 
        related_name='dogs', 
        on_delete=models.CASCADE)
    MALE = 'M'
    FEMALE = 'F'
    GENDER_CHOICES = (
        (MALE, 'Male'),
        (FEMALE, 'Female'),
    )
    gender = models.CharField(
        max_length=2,
        choices=GENDER_CHOICES,
        default=MALE,
    )
    class Meta:
        ordering = ('name',)
        
    def __str__(self):
        return self.name    


