"""
Book: Building RESTful Python Web Services
"""
from rest_framework import serializers
from dogs.models import Breed
from dogs.models import Dog


class BreedSerializer(serializers.HyperlinkedModelSerializer):
    """ the dogs name that we specified as the related_name string value when we created the dog_category field as a models.
    ForeignKey instance in the Dog model. This way, the dogs field will provide us with an array of hyperlinks to each dog that belong to the dog category."""
    dogs = serializers.HyperlinkedRelatedField(
    #HyperlinkedRelatedField with many and read_only equal to True because it is a one-to-many relationship and it is read-only
        many=True,
        read_only=True,
        view_name='dog-detail')
    size = serializers.ChoiceField(
        choices=Breed.SIZE_CHOICES)
    size_description = serializers.CharField(
        source='get_size_display', 
        read_only=True)
    # A Meta inner class that declares two attributes: model and fields.
    class Meta:
        model = Breed  #The model attribute specifies the model related to the serializer, that is, the DogCategory class
        # The fields attribute specifies a tuple of string whose values indicates the field names that we want 
        # to include in the serialization from the related model. We also specified pk and url as members of tuple
        fields = (
            'url',
            'pk',
            'name',
            'size',
            'size_description',
            'frendliness',
            'trainability',
            'sheddingamount',
            'exerciseneeds',
            'dogs')


class DogSerializer(serializers.HyperlinkedModelSerializer):
    # We want to display the dog cagory's name instead of the id
    breed = serializers.SlugRelatedField(queryset=Breed.objects.all(), slug_field='name')
    gender = serializers.ChoiceField(
        choices=Dog.GENDER_CHOICES)
    gender_description = serializers.CharField(
        source='get_gender_display', 
        read_only=True)

    class Meta:
        model = Dog
        fields = (
            'url',
            'breed',
            'name',
            'age',
            'gender',
            'gender_description',
            'color',
            'favoritefood',
            'favoritetoys')
